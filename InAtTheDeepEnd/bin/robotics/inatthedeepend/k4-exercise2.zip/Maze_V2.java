package robotics.inatthedeepend;

import lejos.nxt.Button;
import lejos.nxt.Motor;
import lejos.nxt.SensorPort;
import lejos.nxt.TouchSensor;
import lejos.nxt.UltrasonicSensor;
import lejos.util.Delay;

public class Maze_V2 {

	
	public static void main(String[] args) {
		RobotInformation robot = new RobotInformation();
        UltrasonicSensor range = new UltrasonicSensor(SensorPort.S4);
        TouchSensor sensor = new TouchSensor(SensorPort.S1);
        
        robot.SetSpeed(200);
    	range.continuous();
    	
        robot.ButtonPress();
        while(Button.ENTER.isUp())
        {
         	
        	
        	
        	
        	
        	if(range.getDistance() < 10 )
        	{
        		robot.Stop();
        		Motor.C.forward();
        		Delay.msDelay(500);
        		robot.Stop();
        		Motor.B.forward();
        		Delay.msDelay(500);
        		robot.Stop();
        	}
        	
        	if(range.getDistance() > 20 && range.getDistance() <=30 )
        	{
        		robot.Stop();
        		Motor.B.forward();
        		Delay.msDelay(500);
        		robot.Stop();
        		Motor.C.forward();
        		Delay.msDelay(500);
        		robot.Stop();
        	}
        	
        	 if(range.getDistance() > 30 && !sensor.isPressed())
             {	
             	robot.Stop();
             	robot.NoWall(); //if wall is out of range.... turn left and continue
             	robot.Stop();
             }
        	 
        	 if(sensor.isPressed())
        	 {
        		 robot.Backwards();
        		 robot.MotorB();
        	 }
        	 else
        	 {
        		 robot.Drive();
        	 }
        }

	}

}
